package com.example.gymtracker;

import android.content.Context;

import com.example.gymtracker.data.Workout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SaveData {

    public static void saveData(Context c){
        try{
            System.out.println("Saving");
            File file = new File(c.getFilesDir(), "save.dat");
            if(file.exists()){
                file.delete();
            }
            FileOutputStream fos = c.openFileOutput("save.dat", Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(MainActivity.workouts);
            os.close();
            fos.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}

package com.example.gymtracker;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gymtracker.data.Day;
import com.example.gymtracker.data.Set;
import com.example.gymtracker.data.Exercise;

import java.util.Timer;
import java.util.TimerTask;

public class ExerciseActivity extends AppCompatActivity {

    private int setCount = 1;
    private Day day = new Day();
    private Exercise exercise;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);
        setLongClickListeners();
        exercise = (Exercise) getIntent().getSerializableExtra("exercise");
        TextView l = (TextView) this.findViewById(R.id.workoutTitle3);
        l.setText(exercise.getName());
        initialisePrevious();
    }

    public void initialisePrevious(){

        Day previousDay = exercise.getLastDay();
        if(previousDay==null){
            TextView t = (TextView) this.findViewById(R.id.previousRep);
            t.append("\nYou havnt done this exercise before");
        }else{
            TextView set = (TextView) this.findViewById(R.id.previousSet);
            TextView rep = (TextView) this.findViewById(R.id.previousRep);
            TextView weight = (TextView) this.findViewById(R.id.previousWeight);
            TextView repText= (TextView) this.findViewById(R.id.repText);
            TextView weightText= (TextView) this.findViewById(R.id.weightText);
            set.append("Set");
            rep.append("Rep");
            weight.append("Weight");
            for(int i=1;i<previousDay.getSetNum();i++){
                Set s= previousDay.getSet(i);
                if(i==1){
                    repText.setText(""+s.rep);
                    weightText.setText(""+s.weight);
                }
                set.append("\n"+i);
                rep.append("\n"+s.rep);
                weight.append("\n"+s.weight);
            }
        }
    }

    public void progress_Click(View v){
        Intent intent = new Intent(this, ProgressActivity.class);
        intent.putExtra("exercise",exercise);
        startActivity(intent);
    }


    public void enterSet_Click(View v){
        TextView setText = this.findViewById(R.id.setNumber);
        TextView rep = this.findViewById(R.id.repText);
        TextView weight = this.findViewById(R.id.weightText);
        day.addSet(Integer.parseInt(rep.getText().toString()),Double.parseDouble(weight.getText().toString()));
        setText.setText("Set : "+(++setCount));
        System.out.println(day.getSet(1).rep+" "+day.getSet(1).weight);
    }

    public void completeExercise_Click(View v){
        if(day.getSetNum()==1){
            Toast.makeText(this, "You havn't added any Sets!", Toast.LENGTH_SHORT).show();
            return;
        }
        exercise.addDay(day);
        Intent returnIntent = new Intent();
        returnIntent.putExtra("result",exercise);
        setResult(Activity.RESULT_OK,returnIntent);
        this.finish();
    }

    public void back_Click(View v){
        Intent returnIntent = new Intent();
        setResult(Activity.RESULT_CANCELED,returnIntent);
        this.finish();
    }

    public void repUp_Click(View v){
        TextView repText = this.findViewById(R.id.repText);
        Integer num = Integer.parseInt(repText.getText().toString());
        repText.setText((++num).toString());
    }
    public void repDown_Click(View v){
        TextView repText = this.findViewById(R.id.repText);
        Integer num = Integer.parseInt(repText.getText().toString());
        if(--num<0){return;}
        repText.setText((num).toString());
    }
    public void weightUp_Click(View v){
        TextView weightText = this.findViewById(R.id.weightText);
        Double num = Double.parseDouble(weightText.getText().toString());
        num+=0.5;
        weightText.setText(num.toString());
    }
    public void weightDown_Click(View v){
        TextView weightText = this.findViewById(R.id.weightText);
        Double num = Double.parseDouble(weightText.getText().toString());
        num-=0.5;
        if(num<0){return;}
        weightText.setText(num.toString());
    }

    private void setLongClickListeners(){
        final ImageButton upWeight = this.findViewById(R.id.weightUp);
        final ImageButton downWeight = this.findViewById(R.id.weightDown);

        upWeight.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {

                final Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {

                        if(upWeight.isPressed()) {
                            weightUp_Click(upWeight);
                        }
                        else
                            timer.cancel();
                    }
                },50,100);

                return true;
            }
        });
        downWeight.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                final Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {

                        if(downWeight.isPressed()) {
                            weightDown_Click(upWeight);
                        }
                        else
                            timer.cancel();
                    }
                },50,100);

                return true;
            }
        });
    }
}

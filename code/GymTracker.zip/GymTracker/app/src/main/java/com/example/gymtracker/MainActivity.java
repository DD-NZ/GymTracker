package com.example.gymtracker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.gymtracker.data.Workout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private boolean creatingWorkout = false;
    public static ArrayList<Workout> workouts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        load();
        for(int i=0; i<workouts.size();i++){
            addButton(true, workouts.get(i).getName());
        }
    }

    private void load(){
        try{
            System.out.println("Loading");
            FileInputStream fis = this.openFileInput("save.dat");
            ObjectInputStream is = new ObjectInputStream(fis);
            workouts = (ArrayList<Workout>) is.readObject();
            is.close();
            fis.close();

        }   catch(Exception e){
            System.out.println("Created new File");
            File file = new File(this.getFilesDir(), "save.dat");
        }
    }

    public void newWorkout_Click(View v){
        LinearLayout l = (LinearLayout) this.findViewById(R.id.enterWorkout);
        if(creatingWorkout){
            l.removeView(this.findViewById(R.id.sendWorkout));
            creatingWorkout=false;
            return;
        }
        creatingWorkout=true;

        LinearLayout textEntry = new LinearLayout(this);
        textEntry.setBackgroundColor(getColor(R.color.DarkGrey));
        textEntry.setOrientation(LinearLayout.HORIZONTAL);


        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        textParams.weight = 1;
        textParams.setMargins(15,15,15,15);

        EditText  e= new EditText(this);
        e.setId(R.id.workoutInputText);
        e.setLayoutParams(textParams);
        e.setBackgroundColor(getColor(R.color.White));

        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        buttonParams.weight = 6;

        ImageButton b = new ImageButton(this);
        b.setLayoutParams(buttonParams);
        b.setImageDrawable(getDrawable(R.drawable.send));
        b.setColorFilter(getColor(R.color.Orange));
        b.setBackgroundColor(getColor(R.color.DarkGrey));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout c = ((LinearLayout)v.getParent());
                LinearLayout cc = ((LinearLayout) c.getParent());

                String text = ((EditText)c.findViewById(R.id.workoutInputText)).getText().toString();
                if(!text.equals("")){
                    if(!checkOriginal(text)){
                        return;
                    }
                    workouts.add(new Workout(text));
                    addButton(false,text);
                    cc.removeView(c);
                }
            }
        });

        textEntry.addView(e);
        textEntry.addView(b);
        textEntry.setId(R.id.sendWorkout);
        l.addView(textEntry);

    }

    private int getDP(int i){
        float scale = this.getResources().getDisplayMetrics().density;
        return (int)(i*scale+0.5f);
    }


    public void addButton(boolean created,String s){

        LinearLayout l = (LinearLayout) this.findViewById(R.id.workoutScroll);
        int margin = getDP(15);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        params.setMargins(margin,margin,margin,margin);
        params.height=getDP(75);

        Button b =new Button(this);
        b.setLayoutParams(params);
        b.setText(s);
        b.setBackground(getDrawable(R.drawable.roundbutton));
        b.setTextColor(getColor(R.color.Orange));
        b.setTextSize(24);
        b.setAllCaps(false);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToWorkoutActivity(((Button)v).getText().toString());

            }
        });
        l.addView(b);
        if(!created){
            System.out.println("Adsas");
            SaveData.saveData(this);
        }
    }

    public boolean checkOriginal(String s){
        for(Workout w: workouts){
            if(w.getName().equals(s)){
                Toast.makeText(this, "You already have this Workout!", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    public void goToWorkoutActivity(String s){
        Intent intent = new Intent(this, WorkoutActivity.class);
        Workout workout=null;
        for(Workout w: workouts){
            if(w.getName().equals(s)){
                workout=w;
                if(w.getExercises().size()>0){
                }
            }
        }
        intent.putExtra("Workout",workout);
        startActivityForResult(intent,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
              Workout workout = (Workout)data.getSerializableExtra("result");
              for(int i=0; i<workouts.size();i++){
                  Workout w = workouts.get(i);
                  if(workout.getName().equals(w.getName())){
                     workouts.remove(i);
                     workouts.add(i,workout);
                  }
              }
            }
        }
    }
}



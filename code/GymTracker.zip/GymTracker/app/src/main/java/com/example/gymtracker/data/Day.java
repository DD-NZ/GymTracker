package com.example.gymtracker.data;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;

public class Day implements Serializable {

    private int count=1;
    private HashMap<Integer,Set> sets = new HashMap<>();
    public final Date date;

    public Day() {
        this.date = new Date();
    }

    public void addSet(Integer rep, Double kg){
        sets.put(count,new Set(rep,kg));
        count++;
    }
    public Set getSet(int i){
        return sets.get(i);
    }
    public int getSetNum(){
        return count;
    }

    public double get1RM(){
        double total = 0;
        for(int i = 1;i<count;i++){
            Set s = sets.get(i);
            total += s.weight/getpercentage(s.rep)*100;
        }
        return total/count;
    }


    private double getpercentage(int rep){
        switch(rep) {
            case 1:
                return 0.100;
            case 2:
                return 0.95;
            case 3:
                return 0.93;
            case 4:
                return 0.90;
            case 5:
                return 0.87;
            case 6:
                return 0.85;
            case 7:
                return 0.83;
            case 8:
                return 0.80;
            case 9:
                return 0.77;
            case 10:
                return 0.75;
            case 11:
                return 0.73;
            default:
                return 0.70;
        }
    }



}

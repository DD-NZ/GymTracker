package com.example.gymtracker.data;

import java.io.Serializable;

public class Set implements Serializable {
    public final Integer rep;
    public final Double weight;

    public Set(Integer rep, Double weight) {
        this.rep = rep;
        this.weight = weight;
    }
}
